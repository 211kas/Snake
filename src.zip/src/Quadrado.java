import java.util.Arrays;
import java.util.Comparator;

/**
 * Uma classe Quadrao que é constituido por um Array de 4 Pontos do primeiro
 * quadrante.
 *
 * @author Martinus Boom
 * @version 12/03/2024
 */
public class Quadrado extends Retangulo{

    /**
     * Contrui um Quadrado a partir de um Array de Pontos
     * @param pontos Array de Pontos em questao
     */
    public Quadrado(Ponto<Integer>[] pontos){
        super(pontos);
        checkQuadrado(pontos);
    }

    /**
     * Construi um Array de Pontos de uma String de um Quadrado
     *
     * @param s String de pontos de um Quadrado
     */
    public Quadrado(String s){
        this(pontos(s));
    }

    /**
     * Verifica se um Array de pontos corresponde a um Quadrado
     * @param pontos Array de pontos em questão
     */
    private void checkQuadrado(Ponto<Integer>[] pontos) {
        if (pontos.length != 4){
            System.out.println("Quadrado:vi");
            System.exit(0);
        }
        if (pontos[0].dist(pontos[1]) != pontos[2].dist(pontos[3]) || pontos[0].dist(pontos[2]) == 0){
            System.out.println("Quadrado:vi");
            System.exit(0);
        }
    }

    public boolean contains(Ponto<Integer> point) {
        int minX = Arrays.stream(pontos).min(Comparator.comparingInt(Ponto::getX)).orElse(new Ponto<>(0,0)).getX();
        int maxX = Arrays.stream(pontos).max(Comparator.comparingInt(Ponto::getX)).orElse(new Ponto<>(0,0)).getX();
        int minY = Arrays.stream(pontos).min(Comparator.comparingInt(Ponto::getY)).orElse(new Ponto<>(0,0)).getY();
        int maxY = Arrays.stream(pontos).max(Comparator.comparingInt(Ponto::getY)).orElse(new Ponto<>(0,0)).getY();

        return point.getX() >= minX && point.getX() <= maxX &&
                point.getY() >= minY && point.getY() <= maxY;
    }


    @Override
    public String toString() {
        return "Quadrado: " +  Arrays.toString(pontos);
    }
}
