public abstract class Obstaculo {
    public abstract boolean intersectsLine(SegmentoReta seg);

    public abstract boolean isPointInside(Ponto<Integer> p);
}