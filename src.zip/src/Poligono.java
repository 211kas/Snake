import java.util.ArrayList;
import java.util.Arrays;

/**
 * Uma classe Poligono que generaliza todos os Poligonos
 *
 * @author Martinus Boom a75456
 * @version 03/03/2024
 * @inv Uma lista de pontos forma um polígono simples se o número de pontos é superior a dois, não
 * existem três pontos consecutivos colineares e nenhum par de arestas se cruza
 */
public abstract class Poligono extends Obstaculo{

    protected final Ponto<Integer>[] pontos;

    protected SegmentoReta[] segs;
    protected final double perimetro;
    protected Ponto<Double> centro;

    /**
     * Construi um Poligono a partir de um Array de Pontos
     *
     * @param p : Array de Pontos em questao
     */
    public Poligono(Ponto<Integer>[] p){
        check(p);
        this.pontos = p;
        this.segs = seg();
        this.perimetro = perimetro();
        this.centro = centro();

    }

    /**
     * Construi um Array de Pontos de uma String de um Poligono
     *
     * @param p String de pontos de um Poligono
     */
    public Poligono(String p) {
        this(pontos(p));
    }

    /**
     * A partir de uma String returna um Array de Pontos que formam uma Poligono
     *
     * @param s : String que contem o Poligono
     * @return : Array de Pontos que formam um Poligono
     */
    @SuppressWarnings("unchecked")
    public static Ponto<Integer>[] pontos(String s) {
        String[] p = s.split(" ");
        int n;
        int m;
        if (p.length % 2 != 0){
            n = Integer.parseInt(p[0]);
            m = 1;
        } else if (p.length == 6){
            n = 3;
            m = 0;
        } else{
            n = 4;
            m = 0;
        }
        Ponto<Integer>[] ponto = (Ponto<Integer>[])new Ponto<?>[n];
        int j = 0;
        for (int i = m; i < p.length; i += 2) {
            ponto[j++] = new Ponto<Integer>(Integer.parseInt(p[i]), Integer.parseInt(p[i + 1]));
        }
        return ponto;
    }

    /**
     * Verifica se um Array de Pontos representa um Poligono
     *
     * @param p : Array de Pontos em questao
     */
    public void check(Ponto<Integer>[] p) {
        int n = p.length;
        if (n <= 2) {
            System.out.println("Poligono:vi");
            System.exit(0);
        }
        for (int i = 0; i < n; i++) {
            Reta a = new Reta(p[i], p[(i+1) % n]);
            if (a.isCollinear(p[(i+2) % n])) {
                System.out.println("Poligono:vi");
                System.exit(0);
            }
        }
        for (int i = 0; i < n; i++) {
            SegmentoReta a = new SegmentoReta(p[i], p[(i+1) % n]);
            SegmentoReta b = new SegmentoReta(p[(i+2) % n], p[(i+3) % n]);
            if (a.intersect(b)) {
                System.out.println("Poligono:vi");
                System.exit(0);
            }
        }
    }


    /**
     *
     * @return perimetro do Poligono
     */
    public double perimetro() {
        int n = pontos.length;
        double p = pontos[n - 1].dist(pontos[0]);
        for (int i = 0; i < n-1; i++) {
            p+= pontos[i].dist(pontos[i+1]);
        }
        return p;
    }

    /**
     *
     * @return Array de Pontos do Poligono
     */
    public Ponto<Integer>[] getPontos() {
        return pontos;
    }

    /**
     *
     * @return Ponto central do Poligono
     */
    private Ponto<Double> centro() {
        int n = pontos.length;
        double x = 0;
        double y = 0;
        for (Ponto<Integer> p: pontos) {
            x += p.getX();
            y += p.getY();
        }
        return new Ponto<Double>(x/n, y/n);
    }

    /**
     * Faz a translação de um Poligono para um novo Centro dado
     *
     * @param x x do novo Centro
     * @param y y do novo Centro
     */
    public void newCentroide(double x, double y) {
        if (!(centro().getX() == x && centro().getY()== y)) {
            double dx = x - centro().getX();
            double dy = y - centro().getY();
            translation(dx, dy);
        }
    }

    /**
     * Faz a rotação de um Poligono considerando o seu centro como Ponto de rotaçao
     *
     * @param degrees angulo de rotaçao em graus
     */
    public void rotate(int degrees) {
        rotate(centro.getX(), centro.getY(), degrees);
    }

    /**
     * Faz a rotação de um Poligono dado um Ponto de rotaçao
     *
     * @param degrees angulo de rotaçao em graus
     */
    public void rotate(double pX, double pY, int degrees) {
        for (Ponto<Integer> p: pontos) {
            p.rotate(pX, pY, degrees);
        }
    }

    /**
     * Faz a translação de um Poligono dado um deslocamento x e y
     *
     * @param dx deslocamento x
     * @param dy deslocamento y
     */
    public void translation(double dx, double dy) {
        for (Ponto<Integer> p: pontos) {
            p.translation(dx, dy);
        }
    }

    /**
     * Verifica se o Poligono interseta um Poligono dado
     * @param p : Poligono em questão
     * @return True se interseta
     * @return False se não interseta
     */
    public boolean intersect(Poligono p) {
        Ponto<Integer>[] pontosObs = p.getPontos();
        for (int i = 0; i < pontos.length; i++) {
            SegmentoReta a = new SegmentoReta(pontos[i], pontos[(i+1) % pontos.length]);
            for (int k = 0; k < pontosObs.length; k++) {
                SegmentoReta b = new SegmentoReta(pontosObs[k], pontosObs[(k + 1) % pontosObs.length]);
                if (a.intersect(b)) return true;
            }
        }
        return false;
    }

    /**
     * Checks if rectangle collides with line
     *
     * @param line To check if intersects with rectangle
     * @return True if intersects
     */
    public boolean intersectsLine(SegmentoReta line) {
        for (SegmentoReta thisLine : segs)
            if (thisLine.intersect(line))
                return true;
        return false;
    }



    /**
     *
     * @return Poligono em formato string
     */
    @Override
    public String toString() {
        return "Poligono de " + pontos.length + " vertices: " + Arrays.toString(pontos);
    }

    /**
     *
     * @return Array de Segmentos de Reta a partir do Array de Pontos do Poligono
     */
    public SegmentoReta[] seg() {
        int n = pontos.length;
        SegmentoReta[] seg = new SegmentoReta[n];
        for (int i = 0; i < n; i++) {
            seg[i] = new SegmentoReta(pontos[i], pontos[(i+1) % n]);
        }
        return seg;
    }

    /**
     * Verifica se dois Poligonos são duplicados
     *
     * @param obj Poligono a comparar
     * @return True se os dois Poligonos forem iguais
     */
    @Override
    public boolean equals(Object obj) {
        Poligono poligono = (Poligono) obj;
        int size;
        int count = 0;
        if (this.pontos.length == poligono.pontos.length) {
            size = this.pontos.length;
            for (Ponto<Integer> p1: pontos) {
                for (Ponto<Integer> p2: poligono.pontos) {
                    if (p1.equals(p2)){
                        count++;
                        break;
                    }
                }
            }
            return count == size;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(pontos);
    }

    public Ponto<Double> getCentro() {
        return centro;
    }
}


