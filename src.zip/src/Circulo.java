public class Circulo extends Obstaculo {
    private final Ponto<Integer> centro;
    private final double raio;

    public Circulo(Ponto<Integer> c, double r) {
        if (r <= 0) {
            System.out.println("Error: Circle Radius");
            System.exit(1);
        }

        this.centro = c;
        this.raio = r;

    }

    public Circulo(double[] p) {
        this(new Ponto<Integer>((int)p[0], (int)p[1]),  p[2]);
    }

    /**
     * Creates circle from points
     *
     * @param s String should be separated by spaces and needs to have 3 integers
     */
    public Circulo(String s) {
        this(getValues(s));
    }

    /**
     * Creates circle from points
     *
     * @param s String should be separated by spaces and needs to have 3 integers
     */
    private static double[] getValues(String s) {
        String[] aux = s.split(" ");
        return new double[]{Integer.parseInt(aux[1]), Integer.parseInt(aux[2]), Double.parseDouble(aux[3])};
    }

    /**
     * @return Center point
     */
    public Ponto<Integer> getCenter() {
        return centro;
    }

    /**
     * @return Radius
     */
    public double getRadius() {
        return raio;
    }

    /**
     * Checks if circle collides with line
     *
     * @param lineSegment To check if intersects with triangle
     * @return True if intersects
     */
    public boolean intersectsLine(SegmentoReta lineSegment) {
        // Get values
        double x1 = lineSegment.getP1().getX();
        double x2 = lineSegment.getP2().getX();
        double y1 = lineSegment.getP1().getY();
        double y2 = lineSegment.getP2().getY();
        double circlex = centro.getX();
        double circley = centro.getY();

        //Calculate change in x and y for the segment
        double deltax = x2 - x1;
        double deltay = y2 - y1;

        //Set up our quadratic formula
        double a = deltax * deltax + deltay * deltay;
        double b = 2 * (deltax * (x1 - circlex) + deltay * (y1 - circley));
        double c = (x1 - circlex) * (x1 - circlex) + (y1 - circley) * (y1 - circley) - raio * raio;

        //Check if there is a negative in the discriminant
        double discriminant = b * b - 4 * a * c;
        if (discriminant < 0)
            return false;

        //Try both +- in the quadratic formula
        double quad1 = (-b + Math.sqrt(discriminant)) / (2 * a);
        double quad2 = (-b - Math.sqrt(discriminant)) / (2 * a);

        //If the result is between 0 and 1, there is an intersection
        if (quad1 >= 0 && quad1 <= 1)
            return true;
        else return quad2 >= 0 && quad2 <= 1;
    }

    @Override
    public boolean isPointInside(Ponto<Integer> p) {
        double distance = Math.sqrt(Math.pow(p.getX() - centro.getX(), 2) + Math.pow(p.getY() - centro.getY(), 2));
        return distance <= raio;
    }
}

