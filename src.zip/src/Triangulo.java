import java.util.Arrays;

/**
 * Uma classe Triangulo que é constituido por um Array de 3 Pontos do primeiro
 * quadrante.
 *
 * @author Martinus Boom
 * @version 12/03/2024
 */
public class Triangulo extends Poligono{

    /**
     * Constroi um Triangulo a partir de um Array de Pontos
     * @param pontos Array de Pontos em questao
     */
    public Triangulo(Ponto<Integer>[] pontos){
        super(pontos);
        checkTriangulo(pontos);
    }

    /**
     * Construi um Array de Pontos de uma String de um Triangulo
     *
     * @param s String de pontos de um Poligono
     */
    public Triangulo(String s){
        this(pontos(s));
    }

    /**
     * Verifica se um Array de pontos corresponde a um Triangulo
     * @param p Array de pontos em questão
     */
    private void checkTriangulo(Ponto<Integer>[] p) {
        if (p.length != 3) {
            System.out.println("Triângulo:vi");
            System.exit(0);
        }
        if (p[0].isCollinear(p[1], p[2])) {
            System.out.println("Triângulo:vi");
            System.exit(0);
        }
    }

    public static double area(Ponto<Integer> p1, Ponto<Integer> p2, Ponto<Integer> p3) {
        return Math.abs((p1.getX() * (p2.getY() - p3.getY()) + p2.getX() * (p3.getY() - p1.getY()) + p3.getX() * (p1.getY() - p2.getY())) / 2.0);
    }

    /**
     * @param p Point to check
     * @return True if point is inside
     * @see <a href="https://www.tutorialspoint.com/Check-whether-a-given-point-lies-inside-a-Triangle">LINK</a>
     */
    @Override
    public boolean isPointInside(Ponto<Integer> p) {
        double A = area(pontos[0], pontos[1], pontos[2]);
        double A1 = area(p, pontos[1], pontos[2]);
        double A2 = area(pontos[0], p, pontos[2]);
        double A3 = area(pontos[0], pontos[1], p);
        return (A == A1 + A2 + A3);
    }

    @Override
    public String toString() {
        return "Triangulo: " +  Arrays.toString(pontos);
    }
}
