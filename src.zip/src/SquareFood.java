import java.util.LinkedList;

public class SquareFood extends Food {
    private Quadrado square;

    public SquareFood(Snake s, Ponto<Integer> foodPoint, Obstaculo[] obs, int score, Quadrado square) {
        super(s, foodPoint, obs, score);
        this.square = square;
    }

    @Override
    public boolean isContainedCompletelyBy(Quadrado snakeHead) {
        for (Ponto<Integer> corner : square.getPontos()) {
            if (!snakeHead.contains(corner)) {
                return false;
            }
        }
        return true;
    }


}
