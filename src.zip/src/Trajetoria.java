
import java.util.ArrayDeque;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Uma classe Trajetoria que é constituida  por uma sequência de pontos do primeiro quadrante
 *
 * @author Martinus Boom a75456
 * @version 25/02/2024
 * @inv É uma Trajetoria se o número de pontos é superior a 1 e não
 * existem dois pontos consecutivos colineares
 */
public class Trajetoria implements AStar{
    private final Queue<Ponto<Integer>> traj;

    /**
     * Empty Trajetoria
     */
    public Trajetoria() {
        traj = new ArrayDeque<>();
    }

    public Trajetoria(Ponto<Integer> start, Ponto<Integer>  end, Obstaculo[] obstacle, int squareSize) {
        LinkedList<Node> points = bestPath(start, end, obstacle, squareSize);
        Queue<Ponto<Integer> > result = new ArrayDeque<>();
        for (Node n : points)
            result.add(n.getP());
        this.traj = result;
    }

    public Queue<Ponto<Integer>> getPoints() {
        return traj;
    }

    private void remove() {
        traj.remove();
    }

    public Ponto<Integer> nextPoint() {
        return traj.poll();
    }

    public boolean isEmpty() {
        return traj.isEmpty();
    }


    public int size() {
        return traj.size();
    }

}
