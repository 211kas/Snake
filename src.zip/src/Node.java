import java.util.Objects;

/**
 * Auxiliary class for a* interface.
 * Stores distance from start Node to current Node (gValue).
 * Stores heuristic distance value from current Node to end Node (hValue)
 * Final cost = gCost + hCost.
 * Parent Node is used to return best path.
 *
 * @author PL1
 * @version 1.0
 * @inv stamina < 0
 */

public class Node {
    private final Ponto<Integer> p;
    private int gCost;
    private int hCost;
    private int fCost;
    private Node parent;

    /**
     * Initializes Node with gcost and hCost
     *
     * @param p     Point
     * @param gCost Cost from start to current Node
     * @param hCost Cost from current to end Node
     */
    public Node(Ponto<Integer> p, int gCost, int hCost) {
        this.p = p;
        this.gCost = gCost;
        this.hCost = hCost;
        fCost = gCost + hCost;
        parent = null;
    }

    /**
     * Comparator for Priority queue.
     * First comes Nodes with the lowest final cost. If it's a draw, chooses the one with lowest hCost
     *
     * @param n1 Node 1
     * @param n2 Node 2
     * @return 1 if Node 2 is closer to end goal, -1 if Node 1 is closer to end goal.
     */
    public static int comparator(Node n1, Node n2) {
        if (n1.fCost < n2.fCost)
            return -1;

        if (n1.fCost > n2.fCost)
            return 1;

        if (n1.hCost < n2.hCost)
            return -1;

        if (n1.hCost > n2.hCost)
            return 1;

        return 0;
    }

    /**
     * @return gCost
     */
    public int getgCost() {
        return gCost;
    }

    /**
     * Set G cost
     *
     * @param gCost Cost from start to current Node
     */
    public void setgCost(int gCost) {
        this.gCost = gCost;
    }

    /**
     * Set H cost and update fCost
     *
     * @param hCost Heuristic value to be updated
     */
    public void sethCost(int hCost) {
        this.hCost = hCost;
        fCost = gCost + hCost;
    }


    /**
     * @return Parent Node
     */
    public Node getParent() {
        return parent;
    }

    /**
     * Set Parent Node
     *
     * @param parent Parent Node
     */
    public void setParent(Node parent) {
        this.parent = parent;
    }

    /**
     * @return Current Node Point
     */
    public Ponto<Integer> getP() {
        return p;
    }

    /**
     * Uses Manhattan distance to calculate heuristic Values.
     * Sides Cost is 1 * 10 = 10;
     * Diagonal Cost is sqrt(1^2 + 1^2) * 10 = 14.
     * Both values are multiplied times 10 to avoid using doubles.
     *
     * @param goal Goal point
     * @return Distance between current Node and end point
     */
    public int calculateDistance(Ponto<Integer> goal) {
        int xDistance = Math.abs(p.getX() - goal.getX());
        int yDistance = Math.abs(p.getY() - goal.getY());
        int remainder = Math.abs(xDistance - yDistance);
        int DIAGONAL_COST = 14;
        int SIDES_COST = 10;
        return DIAGONAL_COST * Math.min(xDistance, yDistance) + SIDES_COST * remainder;
    }

    /**
     * Check if current Node as the same coordinates as point
     *
     * @param point Point to compare coordinates
     * @return True if both coordinates are equal.
     */
    public boolean isEqualToPoint(Ponto<Integer> point) {
        return Objects.equals(p.getX(), point.getX()) && Objects.equals(p.getY(), point.getY());
    }

    @Override
    public String toString() {
        return p.toString();
    }
}

