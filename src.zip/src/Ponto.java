import java.util.Objects;

/**
 * Uma classe Ponto genérica onde os pontos pertencem ao primeiro quadrante.
 *
 * @param <T> O tipo numérico do ponto (Integer, Double, etc.)
 * @version 25/02/2024
 * @inv x >= 0 && y >= 0
 */
public class Ponto<T extends Number> {
    private T x;
    private T y;

    /**
     * Constroi um Ponto a partir de duas coordenadas
     *
     * @param x : coordenada do Eixo x
     * @param y : coordenada do Eixo y
     */
    public Ponto(T x, T y) {
        check(x);
        check(y);
        this.x = x;
        this.y = y;
    }


    /**
     * Verifica se o Ponto pertence ao primeiro quadrante
     *
     * @param n : coordenada de um dos Eixos do Ponto
     */
    public void check (T n) {
        if (n.doubleValue() < 0) {
            System.out.println("Ponto:vi");
            System.exit(0);
        }
    }

    /**
     * Calcula a distância entre dois Pontos
     *
     * @param p : coordenadas de um Ponto
     * @return distancia entre dois Pontos
     */
    double dist(Ponto<T> p){
        double dx = x.doubleValue() - p.x.doubleValue();
        double dy = y.doubleValue() - p.y.doubleValue();
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Returna a coordenada do Eixo x
     *
     * @return coordenada do Eixo x
     */
    public T getX() {
        return x;
    }

    /**
     * Returna a coordenada do Eixo y
     *
     * @return coordenada do Eixo y
     */
    public T getY() {
        return y;
    }

    /**
     *
     * @param newX Novo x do Ponto
     */
    public void setX(T newX) {
        check(newX);
        this.x = newX;
    }

    /**
     *
     * @param newY Novo y do Ponto
     */
    public void setY(T newY) {
        check(newY);
        this.y = newY;
    }

    /**
     * Faz a translação de um Ponto dado um deslocamento x e y
     *
     * @param dx deslocamento x
     * @param dy deslocamento y
     */
    public void translation(double dx, double dy) {
        double newX = x.doubleValue() + dx;
        double newY = y.doubleValue() + dy;
        setX(convertToT(newX));
        setY(convertToT(newY));
    }

    /**
     * Faz a rotação de um Ponto dado um ponto de rotação e a rotação em graus
     *
     * @param pX x do ponto de rotação
     * @param pY y do ponto de rotação
     * @param degrees rotação em graus
     */
    public void rotate(double pX, double pY, int degrees) {
        double rad = Math.toRadians(degrees);
        double dx = x.doubleValue() - pX;
        double dy = y.doubleValue() - pY;
        double newX = ((Math.cos(rad) * dx) - (Math.sin(rad) * dy)) + pX;
        double newY = ((Math.sin(rad) * dx) + (Math.cos(rad) * dy)) + pY;
        setX(convertToT(newX));
        setY(convertToT(newY));
    }

    /**
     * Verifica se tres pontos sao colineares
     *
     * @param p1 segundo ponto em questao
     * @param p2 terceiro ponto em questao
     * @return True se tres pontos sao colineares
     */
    public boolean isCollinear(Ponto<T> p1, Ponto<T> p2) {
        return ((p1.y.intValue() - y.intValue()) * (p2.x.intValue() - x.intValue())) == ((p2.y.intValue() - y.intValue()) * (p1.x.intValue() - x.intValue()));
    }

    public boolean isInside(Obstaculo[] obs) {
        for (Obstaculo x : obs)
            if (x.isPointInside((Ponto<Integer>) this))
                return true;
        return false;
    }

    /**
     *
     * @param o Ponto a comparar
     * @return True se dois pontos sao iguais
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Ponto<?> ponto)) return false;
        return Objects.equals(x, ponto.x) && Objects.equals(y, ponto.y);
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }

    /**
     *
     * @return Ponto formato string
     */
    @Override
    public String toString() {
        return "(" + x.intValue() + "," +  y.intValue() + ")";
    }

    /**
     * Converte Ponto formato T para int ou double consoante a sua instância
     *
     * @param value valor a converter
     * @return Ponto no seu formato
     */
    @SuppressWarnings("unchecked")
    private T convertToT(double value) {
        if (x instanceof Integer) {
            return (T) Integer.valueOf((int) Math.round(value));
        } else if (x instanceof Double) {
            return (T) Double.valueOf(value);
        }
        throw new IllegalArgumentException("Tipo não suportado para conversão");
    }


}