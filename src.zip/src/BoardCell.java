public class BoardCell {
    private boolean isOccupiedBySnakeHead;

    private boolean isOccupiedBySnakeBody;
    private boolean isOccupiedByFood;
    private boolean isOccupiedByObstacle;

    // Construtor
    public BoardCell() {
        this.isOccupiedBySnakeHead = false;
        this.isOccupiedBySnakeBody = false;
        this.isOccupiedByFood = false;
        this.isOccupiedByObstacle = false;
    }

    // Métodos de acesso e modificação das propriedades
    public boolean isOccupiedBySnakeHead() {
        return isOccupiedBySnakeHead;
    }

    public void setOccupiedBySnakeHead(boolean occupiedBySnake) {
        isOccupiedBySnakeHead = occupiedBySnake;
    }

    public boolean isOccupiedBySnakeBody() { return isOccupiedBySnakeBody;}

    public void setOccupiedBySnakeBody(boolean occupiedBySnake) {
        isOccupiedBySnakeBody = occupiedBySnake;
    }


    public boolean isOccupiedByFood() {
        return isOccupiedByFood;
    }

    public void setOccupiedByFood(boolean occupiedByFood) {
        isOccupiedByFood = occupiedByFood;
    }

    public boolean isOccupiedByObstacle() {
        return isOccupiedByObstacle;
    }

    public void setOccupiedByObstacle(boolean occupiedByObstacle) {
        isOccupiedByObstacle = occupiedByObstacle;
    }

    // Método para verificar se a célula está vazia
    public boolean isEmpty() {
        return !isOccupiedBySnakeHead && !isOccupiedByFood && !isOccupiedByObstacle && !isOccupiedBySnakeBody;
    }
}

