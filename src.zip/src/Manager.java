import java.lang.reflect.Constructor;
import java.util.Random;

public class Manager {
    private Snake snake;
    private final FoodQueue foodQueue;
    private final Obstaculo[] obstacles;

    Manager(Obstaculo[] obs, Snake s) {
        snake = s;
        foodQueue = new FoodQueue();
        obstacles = obs;
    }

    public boolean isFoodAvailable() {
        return false;
    }

    public void addFoodRequest(Food request) {
        foodQueue.add(request);
    }

    public void checkAllFoods() {
        foodQueue.checkAllFoods(snake);
    }

    public void update() {
        checkAllFoods();
        snake.update();
    }

    public void generateFood(int boardWidth, int boardHeight, Class<?> foodClass, int score) {
        Random rand = new Random();
        Ponto<Integer> position;
        boolean positionValid;
        int foodSize = rand.nextInt(snake.getSquareSize()) + 1; // Determinar o tamanho da comida

        do {
            int x = rand.nextInt(boardWidth - foodSize); // Gera x dentro dos limites do tabuleiro
            int y = rand.nextInt(boardHeight - foodSize); // Gera y dentro dos limites do tabuleiro
            position = new Ponto<>(x, y);
            positionValid = true;

            // Verificando se a comida está dentro do corpo da cobra
            for (Quadrado part : snake.getBody()) {
                // Verificar se todos os pontos da comida estão fora do quadrado do corpo da cobra
                for (int i = 0; i < foodSize; i++) {
                    for (int j = 0; j < foodSize; j++) {
                        if (part.contains(new Ponto<>(x + i, y + j))) {
                            positionValid = false;
                            break;
                        }
                    }
                    if (!positionValid) break;
                }
                if (!positionValid) break;
            }
        } while (!positionValid);

        try {
            if (foodClass == SquareFood.class) {
                // Criar pontos para o quadrado da comida
                Quadrado foodSquare = new Quadrado(new Ponto[]{
                        new Ponto<>(position.getX(), position.getY()),
                        new Ponto<>(position.getX() + foodSize - 1, position.getY()),
                        new Ponto<>(position.getX() + foodSize - 1, position.getY() + foodSize - 1),
                        new Ponto<>(position.getX(), position.getY() + foodSize - 1)
                });
                Constructor<?> constructor = foodClass.getConstructor(Snake.class, Ponto.class, Obstaculo[].class, int.class, Quadrado.class);
                Food food = (Food) constructor.newInstance(snake, position, obstacles, score, foodSquare);
                addFoodRequest(food);
                System.out.println("Food created at: " + position.getX() + ", " + position.getY());
                snake.setCurrentFood(food);
            } else if (foodClass == CircleFood.class) {
                double radius = rand.nextDouble() * (snake.getSquareSize() / 2.0) + 0.1;
                Circulo foodCircle = new Circulo(position, radius);
                Constructor<?> constructor = foodClass.getConstructor(Snake.class, Ponto.class, Obstaculo[].class, int.class, Circulo.class);
                Food food = (Food) constructor.newInstance(snake, position, obstacles, score, foodCircle);
                addFoodRequest(food);
                System.out.println("Food created at: " + position.getX() + ", " + position.getY());
                snake.setCurrentFood(food);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }







    public FoodQueue getFoodQueue() {
        return foodQueue;
    }

    public Snake getSnake() {
        return snake;
    }

    public void setSnake(Snake snake) {
        this.snake = snake;
    }

    public Obstaculo[] getObstacles() {
        return snake.getObstacles();
    }
}

