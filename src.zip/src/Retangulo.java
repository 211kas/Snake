import java.util.Arrays;

/**
 * Uma classe Retangulo que é constituido por 2 Pontos do primeiro
 * quadrante (Ponto Inferior Esquerdo e Ponto Superior Direito).
 *
 * @author Martinus Boom
 * @version 04/03/2024
 */
public class Retangulo extends Poligono {


    /**
     * Contrui um Retangulo a partir de um Array de Pontos
     *
     * @param pontos Array de Pontos em questao
     */
    public Retangulo(Ponto<Integer>[] pontos) {
        super(pontos);
        checkRetangulo(pontos);
    }

    /**
     * Construi um Array de Pontos de uma String de um Retangulo
     *
     * @param s String de pontos de um Poligono
     */
    public Retangulo(String s) {
        this(pontos(s));
    }

    /**
     * Verifica se um Array de pontos corresponde a um Retangulo
     *
     * @param pontos Array de pontos em questão
     */
    public void checkRetangulo(Ponto<Integer>[] pontos) {
        if (pontos.length != 4) {
            System.out.println("Retângulo:vi");
            System.exit(0);
        }
        if (pontos[0].dist(pontos[2]) != pontos[1].dist(pontos[3]) || pontos[0].dist(pontos[2]) == 0) {
            System.out.println("Retângulo:vi");
            System.exit(0);
        }
    }

    /**
     * Verifica se o Retangulo interseta com um dado Retangulo
     *
     * @param r2 : Retangulo a ver se interseta
     * @return True se interseta
     * @return False se não interseta
     */
    public boolean intersectRet(Retangulo r2) {
        double minX_r1 = pontos[0].getX();
        double minY_r1 = pontos[0].getY();
        double maxX_r1 = pontos[2].getX();
        double maxY_r1 = pontos[2].getY();
        double minX_r2 = r2.pontos[0].getX();
        double minY_r2 = r2.pontos[0].getY();
        double maxX_r2 = r2.pontos[2].getX();
        double maxY_r2 = r2.pontos[2].getY();
        return minX_r1 < maxX_r2 && minY_r1 < maxY_r2 && maxX_r1 > minX_r2 && maxY_r1 > minY_r2;
    }

    @Override
    public String toString() {
        return "Retangulo: " + Arrays.toString(pontos);
    }

    /**
     * @param p
     * @return
     * @see <a href="https://btechgeeks.com/java-program-to-check-whether-a-given-point-lies-inside-a-rectangle-or-not/">Link</a>
     */
    @Override
    public boolean isPointInside(Ponto<Integer> p) {
        double d1 = (p.getX() - pontos[0].getX()) * (pontos[1].getY() - pontos[0].getY()) - (pontos[1].getX() - pontos[0].getX()) * (p.getY() - pontos[0].getY());
        double d2 = (p.getX() - pontos[1].getX()) * (pontos[2].getY() - pontos[1].getY()) - (pontos[2].getX() - pontos[1].getX()) * (p.getY() - pontos[1].getY());
        double d3 = (p.getX() - pontos[2].getX()) * (pontos[3].getY() - pontos[2].getY()) - (pontos[3].getX() - pontos[2].getX()) * (p.getY() - pontos[2].getY());
        double d4 = (p.getX() - pontos[3].getX()) * (pontos[0].getY() - pontos[3].getY()) - (pontos[0].getX() - pontos[3].getX()) * (p.getY() - pontos[3].getY());

        return ((d1 < 0 && d2 < 0 && d3 < 0 && d4 < 0) || (d1 > 0 && d2 > 0 && d3 > 0 && d4 > 0));

    }
}

