import java.util.LinkedList;

public abstract  class Food {
    public static final int WAITING = 0;
    public static final int IN_PROGRESS = 1;
    public static final int FINISHED = 2;

    private final Snake snake;
    private final Ponto<Integer> foodPoint;
    private Trajetoria bestPath;
    private int status;
    private final int score;
    private final Obstaculo[] obstacles;

    public Food(Snake s, Ponto<Integer> foodPoint, Obstaculo[] obs, int score) {
        this.snake = s;
        this.foodPoint = foodPoint;
        this.obstacles = obs;
        this.score = score;
        this.status = WAITING;
        if (!s.getBody().isEmpty() && snake.getMode() == Snake.GameMode.AUTO) {
            this.bestPath = new Trajetoria(snake.getBody().getFirst().getPontos()[0], foodPoint, obs, snake.getSquareSize());
        } else {
            this.bestPath = null;
        }
    }

    public void calculatePath(Ponto<Integer> start, int squareSize) {
        // Recalcula o caminho mais rápido da posição atual para a comida
        if (status == WAITING || status == IN_PROGRESS) {
            this.bestPath = new Trajetoria(start, foodPoint, obstacles, squareSize);
        }
    }

    // Getters and Setters
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Snake getSnake() {
        return snake;
    }

    public Ponto<Integer> getFoodPoint() {
        return foodPoint;
    }

    public Trajetoria getBestPath() {
        return bestPath;
    }

    public int getScore() {
        return score;
    }

    public abstract boolean isContainedCompletelyBy(Quadrado snakeHead);
}
