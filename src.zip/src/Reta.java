/**
 * Uma classe Reta que é constituido por dois Pontos do primeiro
 * quadrante que compoem uma reta.
 *
 * @author Martinus Boom a75456
 * @version 25/02/2024
 * @inv p1.dist(p2) != 0 A distancia entre os dois pontos tem de ser
 * diferente de zero para formar um segmento de reta.
 */
public class Reta {

    private final Ponto<Integer> p1, p2;

    /**
     * Constroi uma Reta a partir de Dois Pontos do primeiro quadrante
     *
     * @param p1 : Primeiro ponto do Segemento de Reta
     * @param p2 : Segundo ponto do Segemento de Reta
     */
    public Reta(Ponto<Integer> p1, Ponto<Integer> p2) {
        check(p1, p2);
        this.p1 = p1;
        this.p2 = p2;
    }

    /**
     * Verifica se é uma Reta
     *
     * @param p1 : Primeiro ponto do Segmento de Reta
     * @param p2 : Segundo ponto do Segmento de Reta
     */
    public void check(Ponto<Integer> p1, Ponto<Integer> p2){
        if (p1.dist(p2) == 0) {
            System.out.println("Reta:vi");
            System.exit(0);
        }
    }

    /**
     * Verifica se uma Reta é colinear com um certo Ponto
     *
     * @param p : Ponto em questao
     * @return True se o Ponto for colinear com a Reta
     */
    public boolean isCollinear(Ponto<Integer> p) {
        return (p1.getX() - p.getX()) * (p2.getY() - p.getY()) == (p2.getX() - p.getX()) * (p1.getY() - p.getY());
    }

    /**
     * @return Coordenadas do primeiro Ponto da Reta
     */
    public Ponto<Integer> getP1() {
        return p1;
    }

    /**
     * @return Coordenadas do segundo Ponto da Reta
     */
    public Ponto<Integer> getP2() {
        return p2;
    }

}